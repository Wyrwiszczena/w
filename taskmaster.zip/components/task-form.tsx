"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { format } from "date-fns"
import { pl } from "date-fns/locale"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, Clock } from "lucide-react"

type TaskFormProps = {
  task?: {
    id: string
    title: string
    description: string | null
    dueDate: Date | null
    priority: string
    category: string | null
    reminder: Date | null
    status: string
  }
}

export default function TaskForm({ task }: TaskFormProps) {
  const router = useRouter()
  const [title, setTitle] = useState(task?.title || "")
  const [description, setDescription] = useState(task?.description || "")
  const [dueDate, setDueDate] = useState<Date | undefined>(task?.dueDate || undefined)
  const [priority, setPriority] = useState(task?.priority || "MEDIUM")
  const [category, setCategory] = useState(task?.category || "")
  const [reminder, setReminder] = useState<Date | undefined>(task?.reminder || undefined)
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    const taskData = {
      title,
      description,
      dueDate: dueDate ? dueDate.toISOString() : null,
      priority,
      category: category || null,
      reminder: reminder ? reminder.toISOString() : null,
    }

    try {
      const url = task ? `/api/tasks/${task.id}` : "/api/tasks"
      const method = task ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(taskData),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Wystąpił błąd podczas zapisywania zadania")
        setIsLoading(false)
        return
      }

      router.push("/dashboard")
      router.refresh()
    } catch (error) {
      setError("Wystąpił błąd podczas zapisywania zadania")
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      <div className="space-y-2">
        <Label htmlFor="title">Tytuł zadania</Label>
        <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} required />
      </div>
      <div className="space-y-2">
        <Label htmlFor="description">Opis</Label>
        <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={4} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="dueDate">Termin wykonania</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full justify-start text-left font-normal">
                <CalendarIcon className="mr-2 h-4 w-4" />
                {dueDate ? format(dueDate, "PPP", { locale: pl }) : <span>Wybierz datę</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar mode="single" selected={dueDate} onSelect={setDueDate} initialFocus />
            </PopoverContent>
          </Popover>
        </div>
        <div className="space-y-2">
          <Label htmlFor="priority">Priorytet</Label>
          <Select value={priority} onValueChange={(value) => setPriority(value)}>
            <SelectTrigger>
              <SelectValue placeholder="Wybierz priorytet" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="LOW">Niski</SelectItem>
              <SelectItem value="MEDIUM">Średni</SelectItem>
              <SelectItem value="HIGH">Wysoki</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="category">Kategoria</Label>
          <Input
            id="category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            placeholder="np. Praca, Dom, Studia"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="reminder">Przypomnienie</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full justify-start text-left font-normal">
                <Clock className="mr-2 h-4 w-4" />
                {reminder ? format(reminder, "PPP", { locale: pl }) : <span>Ustaw przypomnienie</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar mode="single" selected={reminder} onSelect={setReminder} initialFocus />
            </PopoverContent>
          </Popover>
        </div>
      </div>
      <div className="flex justify-end gap-4">
        <Button type="button" variant="outline" onClick={() => router.back()} disabled={isLoading}>
          Anuluj
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Zapisywanie..." : task ? "Aktualizuj zadanie" : "Dodaj zadanie"}
        </Button>
      </div>
    </form>
  )
}

