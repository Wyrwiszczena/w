"use client"

import { useState } from "react"
import { Calendar, dateFnsLocalizer } from "react-big-calendar"
import "react-big-calendar/lib/css/react-big-calendar.css"
import { format, parse, startOfWeek, getDay } from "date-fns"
import { pl } from "date-fns/locale"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Edit, Trash2 } from "lucide-react"
import { useRouter } from "next/navigation"

type Task = {
  id: string
  title: string
  description: string | null
  dueDate: Date | null
  priority: string
  category: string | null
  reminder: Date | null
  status: string
}

type TaskCalendarProps = {
  tasks: Task[]
}

const locales = {
  pl: pl,
}

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
})

export default function TaskCalendar({ tasks }: TaskCalendarProps) {
  const router = useRouter()
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)

  // Konwertuj zadania do formatu wydarzeń kalendarza
  const events = tasks
    .filter((task) => task.dueDate)
    .map((task) => ({
      id: task.id,
      title: task.title,
      start: new Date(task.dueDate as Date),
      end: new Date(task.dueDate as Date),
      task: task,
    }))

  const handleSelectEvent = (event: any) => {
    setSelectedTask(event.task)
  }

  const handleDeleteTask = async (taskId: string) => {
    if (!confirm("Czy na pewno chcesz usunąć to zadanie?")) return

    try {
      const response = await fetch(`/api/tasks/${taskId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setSelectedTask(null)
        router.refresh()
      }
    } catch (error) {
      console.error("Błąd podczas usuwania zadania:", error)
    }
  }

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case "LOW":
        return "Niski"
      case "MEDIUM":
        return "Średni"
      case "HIGH":
        return "Wysoki"
      default:
        return priority
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "LOW":
        return "bg-blue-100 text-blue-800"
      case "MEDIUM":
        return "bg-yellow-100 text-yellow-800"
      case "HIGH":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "PENDING":
        return "Oczekujące"
      case "IN_PROGRESS":
        return "W trakcie"
      case "COMPLETED":
        return "Ukończone"
      default:
        return status
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "PENDING":
        return "bg-gray-100 text-gray-800"
      case "IN_PROGRESS":
        return "bg-blue-100 text-blue-800"
      case "COMPLETED":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const eventStyleGetter = (event: any) => {
    const priority = event.task.priority
    const status = event.task.status

    let backgroundColor = "#3174ad"

    if (status === "COMPLETED") {
      backgroundColor = "#4caf50"
    } else if (priority === "HIGH") {
      backgroundColor = "#f44336"
    } else if (priority === "MEDIUM") {
      backgroundColor = "#ff9800"
    } else if (priority === "LOW") {
      backgroundColor = "#2196f3"
    }

    return {
      style: {
        backgroundColor,
        borderRadius: "4px",
        opacity: status === "COMPLETED" ? 0.7 : 1,
        color: "white",
        border: "0px",
        display: "block",
      },
    }
  }

  return (
    <Card>
      <CardContent className="p-4">
        <div style={{ height: 600 }}>
          <Calendar
            localizer={localizer}
            events={events}
            startAccessor="start"
            endAccessor="end"
            style={{ height: "100%" }}
            onSelectEvent={handleSelectEvent}
            eventPropGetter={eventStyleGetter}
            culture="pl"
            messages={{
              next: "Następny",
              previous: "Poprzedni",
              today: "Dzisiaj",
              month: "Miesiąc",
              week: "Tydzień",
              day: "Dzień",
              agenda: "Agenda",
              date: "Data",
              time: "Czas",
              event: "Wydarzenie",
              noEventsInRange: "Brak zadań w tym okresie",
            }}
          />
        </div>
      </CardContent>

      <Dialog open={!!selectedTask} onOpenChange={() => setSelectedTask(null)}>
        {selectedTask && (
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{selectedTask.title}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">{selectedTask.description || "Brak opisu"}</p>

              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" className={getPriorityColor(selectedTask.priority)}>
                  {getPriorityLabel(selectedTask.priority)}
                </Badge>
                <Badge variant="secondary" className={getStatusColor(selectedTask.status)}>
                  {getStatusLabel(selectedTask.status)}
                </Badge>
                {selectedTask.category && <Badge variant="outline">{selectedTask.category}</Badge>}
              </div>

              {selectedTask.dueDate && (
                <div className="text-sm">
                  <span className="font-medium">Termin:</span>{" "}
                  {format(new Date(selectedTask.dueDate), "PPP", { locale: pl })}
                </div>
              )}

              {selectedTask.reminder && (
                <div className="text-sm">
                  <span className="font-medium">Przypomnienie:</span>{" "}
                  {format(new Date(selectedTask.reminder), "PPP", { locale: pl })}
                </div>
              )}

              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSelectedTask(null)
                    router.push(`/tasks/${selectedTask.id}/edit`)
                  }}
                >
                  <Edit className="mr-2 h-4 w-4" />
                  Edytuj
                </Button>
                <Button variant="destructive" size="sm" onClick={() => handleDeleteTask(selectedTask.id)}>
                  <Trash2 className="mr-2 h-4 w-4" />
                  Usuń
                </Button>
              </div>
            </div>
          </DialogContent>
        )}
      </Dialog>
    </Card>
  )
}

