"use client"

import { Button } from "@/components/ui/button"
import { signOut } from "next-auth/react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { PlusCircle } from "lucide-react"

export default function DashboardHeader() {
  const pathname = usePathname()

  return (
    <header className="border-b">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6">
          <Link href="/dashboard" className="text-xl font-bold">
            TaskMaster
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link
              href="/dashboard"
              className={`text-sm font-medium transition-colors hover:text-primary ${
                pathname === "/dashboard" ? "text-primary" : "text-muted-foreground"
              }`}
            >
              Dashboard
            </Link>
          </nav>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/tasks/new">
            <Button size="sm">
              <PlusCircle className="mr-2 h-4 w-4" />
              Nowe zadanie
            </Button>
          </Link>
          <Button variant="outline" size="sm" onClick={() => signOut({ callbackUrl: "/" })}>
            Wyloguj
          </Button>
        </div>
      </div>
    </header>
  )
}

