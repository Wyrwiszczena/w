"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, Calendar, CheckCircle, Clock, Edit, MoreHorizontal, Trash2 } from "lucide-react"
import { format } from "date-fns"
import { pl } from "date-fns/locale"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"

type Task = {
  id: string
  title: string
  description: string | null
  dueDate: Date | null
  priority: string
  category: string | null
  reminder: Date | null
  status: string
}

type TaskListProps = {
  tasks: Task[]
}

export default function TaskList({ tasks: initialTasks }: TaskListProps) {
  const router = useRouter()
  const [tasks, setTasks] = useState(initialTasks)
  const [filter, setFilter] = useState("ALL")
  const [categoryFilter, setCategoryFilter] = useState("")
  const [searchQuery, setSearchQuery] = useState("")

  const handleStatusChange = async (taskId: string, newStatus: string) => {
    try {
      const response = await fetch(`/api/tasks/${taskId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status: newStatus }),
      })

      if (response.ok) {
        setTasks((prevTasks) => prevTasks.map((task) => (task.id === taskId ? { ...task, status: newStatus } : task)))
      }
    } catch (error) {
      console.error("Błąd podczas aktualizacji statusu:", error)
    }
  }

  const handleDeleteTask = async (taskId: string) => {
    if (!confirm("Czy na pewno chcesz usunąć to zadanie?")) return

    try {
      const response = await fetch(`/api/tasks/${taskId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setTasks((prevTasks) => prevTasks.filter((task) => task.id !== taskId))
      }
    } catch (error) {
      console.error("Błąd podczas usuwania zadania:", error)
    }
  }

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case "LOW":
        return "Niski"
      case "MEDIUM":
        return "Średni"
      case "HIGH":
        return "Wysoki"
      default:
        return priority
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "LOW":
        return "bg-blue-100 text-blue-800"
      case "MEDIUM":
        return "bg-yellow-100 text-yellow-800"
      case "HIGH":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "PENDING":
        return "Oczekujące"
      case "IN_PROGRESS":
        return "W trakcie"
      case "COMPLETED":
        return "Ukończone"
      default:
        return status
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "PENDING":
        return "bg-gray-100 text-gray-800"
      case "IN_PROGRESS":
        return "bg-blue-100 text-blue-800"
      case "COMPLETED":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Unikalne kategorie dla filtra
  const categories = Array.from(new Set(tasks.map((task) => task.category).filter(Boolean)))

  // Filtrowanie zadań
  const filteredTasks = tasks.filter((task) => {
    // Filtr statusu
    if (filter !== "ALL" && task.status !== filter) return false

    // Filtr kategorii
    if (categoryFilter && task.category !== categoryFilter) return false

    // Wyszukiwanie
    if (
      searchQuery &&
      !task.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !(task.description && task.description.toLowerCase().includes(searchQuery.toLowerCase()))
    )
      return false

    return true
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <Input
            placeholder="Wyszukaj zadania..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full"
          />
        </div>
        <div className="flex gap-4">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtruj po statusie" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Wszystkie</SelectItem>
              <SelectItem value="PENDING">Oczekujące</SelectItem>
              <SelectItem value="IN_PROGRESS">W trakcie</SelectItem>
              <SelectItem value="COMPLETED">Ukończone</SelectItem>
            </SelectContent>
          </Select>

          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtruj po kategorii" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL_CATEGORIES">Wszystkie kategorie</SelectItem>
              {categories.map((category) => (
                <SelectItem key={category} value={category as string}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {filteredTasks.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Brak zadań do wyświetlenia</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTasks.map((task) => (
            <Card key={task.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">{task.title}</CardTitle>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => router.push(`/tasks/${task.id}/edit`)}>
                        <Edit className="mr-2 h-4 w-4" />
                        Edytuj
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleDeleteTask(task.id)} className="text-red-600">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Usuń
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <CardDescription>{task.description || "Brak opisu"}</CardDescription>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="flex flex-wrap gap-2 mb-2">
                  <Badge variant="secondary" className={getPriorityColor(task.priority)}>
                    {getPriorityLabel(task.priority)}
                  </Badge>
                  <Badge variant="secondary" className={getStatusColor(task.status)}>
                    {getStatusLabel(task.status)}
                  </Badge>
                  {task.category && <Badge variant="outline">{task.category}</Badge>}
                </div>
                {task.dueDate && (
                  <div className="flex items-center text-sm text-muted-foreground mb-1">
                    <Calendar className="mr-2 h-4 w-4" />
                    Termin: {format(new Date(task.dueDate), "PPP", { locale: pl })}
                  </div>
                )}
                {task.reminder && (
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="mr-2 h-4 w-4" />
                    Przypomnienie: {format(new Date(task.reminder), "PPP", { locale: pl })}
                  </div>
                )}
              </CardContent>
              <CardFooter className="pt-2">
                <div className="flex justify-between w-full">
                  <Select value={task.status} onValueChange={(value) => handleStatusChange(task.id, value)}>
                    <SelectTrigger className="w-[140px]">
                      <SelectValue placeholder="Zmień status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PENDING">Oczekujące</SelectItem>
                      <SelectItem value="IN_PROGRESS">W trakcie</SelectItem>
                      <SelectItem value="COMPLETED">Ukończone</SelectItem>
                    </SelectContent>
                  </Select>
                  {task.status !== "COMPLETED" ? (
                    <Button variant="outline" size="sm" onClick={() => handleStatusChange(task.id, "COMPLETED")}>
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Ukończ
                    </Button>
                  ) : (
                    <Button variant="outline" size="sm" onClick={() => handleStatusChange(task.id, "PENDING")}>
                      <AlertCircle className="mr-2 h-4 w-4" />
                      Przywróć
                    </Button>
                  )}
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

