import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import { db } from "@/lib/db"
import DashboardHeader from "@/components/dashboard-header"
import TaskList from "@/components/task-list"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import TaskCalendar from "@/components/task-calendar"

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  const tasks = await db.task.findMany({
    where: {
      userId: session.user.id,
    },
    orderBy: {
      dueDate: "asc",
    },
  })

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />
      <main className="flex-1 container py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Twoje zadania</h1>
          <p className="text-muted-foreground">Zarządzaj swoimi zadaniami i śledź postępy</p>
        </div>

        <Tabs defaultValue="list" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="list">Lista zadań</TabsTrigger>
            <TabsTrigger value="calendar">Kalendarz</TabsTrigger>
          </TabsList>
          <TabsContent value="list">
            <TaskList tasks={tasks} />
          </TabsContent>
          <TabsContent value="calendar">
            <TaskCalendar tasks={tasks} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

