import { db } from "@/lib/db"
import { hash } from "bcrypt"
import { NextResponse } from "next/server"
import { z } from "zod"

const userSchema = z.object({
  username: z.string().min(3).max(50),
  email: z.string().email(),
  password: z.string().min(8),
})

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { username, email, password } = userSchema.parse(body)

    // Sprawdź, czy użytkownik już istnieje
    const existingUserByEmail = await db.user.findUnique({
      where: { email },
    })

    if (existingUserByEmail) {
      return NextResponse.json({ error: "Użytkownik z tym adresem email już istnieje" }, { status: 400 })
    }

    const existingUserByUsername = await db.user.findUnique({
      where: { username },
    })

    if (existingUserByUsername) {
      return NextResponse.json({ error: "Użytkownik z tą nazwą już istnieje" }, { status: 400 })
    }

    // Hashuj hasło
    const hashedPassword = await hash(password, 10)

    // Utwórz nowego użytkownika
    const newUser = await db.user.create({
      data: {
        username,
        email,
        password: hashedPassword,
      },
    })

    // Nie zwracaj hasła
    const { password: _, ...user } = newUser

    return NextResponse.json({ user, message: "Użytkownik został zarejestrowany" }, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 })
    }

    return NextResponse.json({ error: "Wystąpił błąd podczas rejestracji" }, { status: 500 })
  }
}

