import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import TaskForm from "@/components/task-form"
import DashboardHeader from "@/components/dashboard-header"
import { db } from "@/lib/db"

export default async function EditTaskPage({
  params,
}: {
  params: { id: string }
}) {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  const task = await db.task.findUnique({
    where: {
      id: params.id,
      userId: session.user.id,
    },
  })

  if (!task) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />
      <main className="flex-1 container py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Edytuj zadanie</h1>
          <p className="text-muted-foreground">Zaktualizuj szczegóły swojego zadania</p>
        </div>
        <div className="max-w-2xl">
          <TaskForm task={task} />
        </div>
      </main>
    </div>
  )
}

