import { Button } from "@/components/ui/button"
import Link from "next/link"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"

export default async function Home() {
  const session = await getServerSession(authOptions)

  if (!session) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-slate-50 to-slate-100 p-4 text-slate-900">
        <div className="w-full max-w-md space-y-8 rounded-lg bg-white p-6 shadow-lg">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-slate-900">TaskMaster</h1>
            <p className="mt-2 text-slate-600">Zarządzaj swoimi zadaniami efektywnie</p>
          </div>
          <div className="flex flex-col space-y-4">
            <Link href="/login" className="w-full">
              <Button className="w-full" size="lg">
                Zaloguj się
              </Button>
            </Link>
            <Link href="/register" className="w-full">
              <Button variant="outline" className="w-full" size="lg">
                Zarejestruj się
              </Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return redirect("/dashboard")
}

