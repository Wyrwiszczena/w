import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import RegisterForm from "@/components/register-form"

export default async function RegisterPage() {
  const session = await getServerSession(authOptions)

  if (session) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-slate-50 to-slate-100 p-4">
      <div className="w-full max-w-md space-y-6 rounded-lg bg-white p-6 shadow-lg">
        <div className="text-center">
          <h1 className="text-2xl font-bold tracking-tight">Zarejestruj się</h1>
          <p className="mt-2 text-sm text-slate-600">Utwórz konto, aby korzystać z TaskMaster</p>
        </div>
        <RegisterForm />
      </div>
    </div>
  )
}

